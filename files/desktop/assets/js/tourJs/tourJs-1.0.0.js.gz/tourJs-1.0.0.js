(function($) {
    $.fn.tourJs = function(options) {

        var defaults = {
            fadeSpeed: 200,
            nextLabel: "Próximo",
            previusLabel: "Voltar",
            finishLabel: "Finalizar",
            finishFunction: function() {
            }
        };

        var settings = $.extend({}, defaults, options);

        var _this = $(this);
        var _body = $("body");
        var size_section = _this.find(".content-tour section").length;
        var size_step = 100 / size_section;
        var current = size_step;
        var finish_button = "<button class=\"btn btn-success pull-right finish\">" + settings.finishLabel + "</button>";

        $(this).addClass("tourJs");
        
        // Verificando se já existe o footer, caso exista o mesmo será apagado e gerado um novo
        if ($(this).find("div").hasClass("footer-tour")) {
            $(this).find("div.footer-tour").remove();
        }
        $(this).append("<div class=\"footer-tour\">" +
                "       <div class=\"progress\">" +
                "           <div class=\"progress-bar\" role=\"progressbar\" aria-valuenow=\"60\" aria-valuemin=\"0\" aria-valuemax=\"100\"></div>" +
                "       </div>" +
                "       <div class=\"buttons\">" +
                "           <button class=\"btn btn-default pull-left previus\">" + settings.previusLabel + "</button>" +
                "           <button class=\"btn btn-primary pull-right next\">" + settings.nextLabel + "</button>" +
                "       </div>" +
                "   </div>");

        setTimeout(function() {
            _this.find(".progress .progress-bar").css("width", current + "%");
        }, 300);

        // Next button
        _this.find(".footer-tour .next").on("click", function() {

            var element = $("section.active").fadeOut(settings.fadeSpeed, function() {
                element.hide().removeClass("active").next().fadeIn(settings.fadeSpeed).addClass("active");

                var posicao = $("section.active").index();

                if (posicao == (size_section - 1)) {
                    _this.find(".footer-tour .next").hide();
                    _this.find(".footer-tour .buttons").append(finish_button);
                }

                _this.find(".footer-tour .previus").show();
                current += size_step;
                _this.find(".progress .progress-bar").css("width", current + "%");

            });
        });

        _this.find(".footer-tour .previus").hide();

        // Previus button
        _this.find(".footer-tour .previus").on("click", function() {

            var element = _this.find("section.active").fadeOut(settings.fadeSpeed, function() {
                element.hide().removeClass("active").prev().fadeIn(settings.fadeSpeed).addClass("active");

                var posicao = _this.find("section.active").index();

                if (posicao == 0) {
                    _this.find(".footer-tour .previus").hide();
                } else {
                    _this.find(".footer-tour .buttons .finish").remove();
                }

                _this.find(".footer-tour .next").show();
                current -= size_step;
                _this.find(".progress .progress-bar").css("width", current + "%");

            });
        });

        _body.on("click", ".footer-tour .finish", settings.finishFunction);

    };
})(jQuery);